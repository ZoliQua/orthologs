$PYTHON setup.py install

